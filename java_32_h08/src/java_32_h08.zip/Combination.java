/**
 * 
 * @author lukas
 * M�gliche Kombinationen
 */
public enum Combination {
	Different,
	Pair,
	Triple
}
